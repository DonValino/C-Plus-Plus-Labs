#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <fstream> 

using namespace std;
void displayGadget(double w,double g,double t);
void actionMethod(double &w,double &g,double &t);
void purchase(int w,int g,int t);
double newPrice(double percentPrice,double oldPrice);
int main(int argc, char *argv[])
{
    double widget = 10;
    double gadget = 15;
    double toggle = 12;
    
    displayGadget(widget,gadget,toggle);
    actionMethod(widget,gadget,toggle);
    system("PAUSE");
    return EXIT_SUCCESS;
}

void displayGadget(double w,double g,double t)
{
     cout << setw(45) << "* * * Welcome User * * *\n" << "Items: \n" << setw(20) <<  "Widget: " << setw(20) << "Gadget: " << setw(20) << "toggle: \n";
     cout  << setw(15) << w << setw(20) << g << setw(20) << t << "\n";
     std::ofstream ofs("C:\\Users\\Jake\\Desktop\\Lab3Partc\\items.txt", std::ofstream::out);
     ofs << setw(45) << "* * * Welcome User * * *\n" << "Items: \n" << setw(20) <<  "Widget: " << setw(20) << "Gadget: " << setw(20) << "toggle: \n" << setw(15) << w << setw(20) << g << setw(20) << t << "\n";
     ofs.close();
}

void purchase(int w,int g,int t){
     int total = (w * 10) + (g * 15) + (t * 12);
     cout << "\nThe total is: " << total << "\n";
}
double newPrice(double percentPrice,double oldPrice)
{

        double newPrice = ((oldPrice) * (1 + percentPrice / 100));
        return newPrice;
}
void actionMethod(double &w,double &g,double &t)
{
     bool notFinished = true;
     int choice = 0;
     int qw = 0;
     int qg = 0;
     int qt = 0;
     
     while(notFinished)
     {
        cout << setw(20) << "Select from one of the following: \n";
        cout << "1. Purchase \n2. Increase a price \n3. Exit Application\n";
        cout <<"Choice: ";
        cin >> choice;
        
        if(choice == 1)
        {
          cout << "You picked purchase;\n" << "Enter the Quantity for widget: ";
          cin >> qw;
          cout << "Enter the Quantity for gadget: ";
          cin >> qg;
          cout << "Enter the quantity for toggle: ";
          cin >> qt;
          purchase(qw,qg,qt);
        }else if(choice == 2)
        {
              char whichItem;
              double newPercentPrice = 0;
              cout << "Pick an item to update it's price:\n";
              cout << "\nLowercase 'w' for widget;\nLowercase 'g' for gaddget;\nLowercase 't' for toggle;\n";
              cout << "Choice: ";
              cin >> whichItem;
              char finish = 'f';

              if(whichItem == 'w')
              {
                 cout << "Enter the % by which the price of widget is to be updated: ";
                 cin >> newPercentPrice;
                 w = newPrice(newPercentPrice,w);
                 cout << "The new price for widget is: " << w << "\n";
                 displayGadget(w,g,t);
                 cout << "Finish with the program? Type in lowercase the keyword 'y':\nOtherwise just type any other letter.";
                 cout << "Exit: ";
                 cin >> finish;
                 if(finish == 'y')
                 {
                     notFinished = false;
                 }
              }else if(whichItem == 'g')
              {
                 cout << "Enter the % by which the price of gadget is to be updated: ";
                 cin >> newPercentPrice;
                 g = newPrice(newPercentPrice,g);
                 cout << "The new price for gadget is: " << g << "\n"; 
                 displayGadget(w,g,t);
                 cout << "Finish with the program? Type in lowercase the keyword 'y':\nOtherwise just type any other letter.";
                 cout << "Exit: ";
                 cin >> finish;
                 if(finish == 'y')
                 {
                     notFinished = false;
                 }
              }else if(whichItem == 't')
              {
                 cout << "Enter the % by which the price of toggle is to be updated: ";
                 cin >> newPercentPrice;
                 t = newPrice(newPercentPrice,t);
                 cout << "The new price for gadget is: " << t << "\n"; 
                 displayGadget(w,g,t);
                 cout << "Finish with the program? Type in lowercase the keyword 'y':\nOtherwise just type any other letter.";
                 cout << "Exit: ";
                 cin >> finish;
                 if(finish == 'y')
                 {
                     notFinished = false;
                 }
              }else
              {
                 cout << "Error, Keyword not recognised. Please try again\n\n";
                 cout << "Finish with the program? Type in lowercase the keyword 'y':\nOtherwise just type any other letter.";
                 cout << "Exit: ";
                 cin >> finish;
                 if(finish == 'y')
                 {
                     notFinished = false;
                 }
              }
              
        }else if(choice == 3)
        {
              notFinished = false;
        }
        
     }
}
