#include "OpenDirectory.h"
#include <string>
OpenDirectory::OpenDirectory()
{
   pdir = NULL;
   pent = NULL;
}

bool OpenDirectory::openDIR(const char *pathIn)
{//Got this from tutorial in Moodle
       filePath = pathIn;
     bool isOpenedProperly = false;
     pdir = opendir (pathIn); // "." will refer to the current directory

	    pent = NULL;
	    if (pdir == NULL) // if pdir wasn't initialised correctly
	    { // print an error message and exit the program
	        cout << ("\nERROR! pdir could not be initialised correctly\n");
	      
	    } // end if

	    while (pent = readdir (pdir)) // while there is still something in the directory to list
	    {
	        if (pent == NULL) // if pent has not been initialised correctly
	        { // print an error message, and exit the program
	            cout << ("\nERROR! pent could not be initialised correctly\n");
	          
	        }
	        // otherwise, it was initialised correctly. let's print it on the console:	        
         cout << ("%s\n", pent->d_name) << "\n";
         isOpenedProperly = true;
	    }
	    return isOpenedProperly;
}
string OpenDirectory::getDIRPath()
{
       filePath.append("\\");
    return (filePath);  
}
OpenDirectory::OpenDirectory(const char *path)
{
  bool openedProperly = false;
  while(openedProperly == false)
  {
   if(openDIR(path) == true)
   {
      openedProperly = true;
   }else
   {
         string pathIn;
         cout << "\nEnter the Path od the folder: ";
         cin >> pathIn;
         const char *c = pathIn.c_str();
         if(openDIR(c) == true)
         {
               openedProperly = true;        
         }
         cout << endl;
   }
  }
}

void OpenDirectory::closeDIR()
{
     closedir(pdir);
}






