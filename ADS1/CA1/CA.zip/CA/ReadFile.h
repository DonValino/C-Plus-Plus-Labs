#include <iostream>
#include <string>
#include <fstream>
using namespace std;

class ReadFile
{
      private:
              string fileName;
              string dirPath;
              string fullFilePath;
              string readLine;
              int blankLineCount;
              int lineCounter;
              ifstream openF;
      public:
             ReadFile();
             ReadFile(string f,string d);
             void setDIRPath(string p);
             void setFileName(string f);
             void openFile();
             void closeFile(ifstream &s);
};
