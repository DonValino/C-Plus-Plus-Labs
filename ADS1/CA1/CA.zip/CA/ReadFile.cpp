#include "ReadFile.h"
#include <fstream>
#include <iostream>
#include <string>
using namespace std;

ReadFile::ReadFile()
{
     fileName = "";
     dirPath = "";
}

ReadFile::ReadFile(string f,string d)
{
   fileName = f;
   dirPath = d;
}

void ReadFile::setDIRPath(string p)
{
     dirPath = p;
}

void ReadFile::setFileName(string f)
{
     fileName = f;
}

void ReadFile::openFile()
{
     blankLineCount = 0;
     lineCounter  = 0;
     fullFilePath = dirPath; 
     fullFilePath.append(fileName);

     openF.open(fullFilePath.c_str());
     if (openF.fail())
	 {
		cout << "File not found"<<endl; // Close the program if the file is not found
		system("pause");
		exit(1);
	 }else
	 {

		while (!openF.eof()) 
		{
			getline(openF, readLine);
			if (readLine == "") {	// this works even if user indents their word.
				blankLineCount++;
			}
			else
				lineCounter++;
			cout << readLine << endl;

		}
	 }

	cout << "\nfile contains " << lineCounter << " Lines of writing and "<< blankLineCount<<" of blank lines" << endl;
	system("pause");
}

void ReadFile::closeFile(ifstream &s)
{
     s.close();
}
