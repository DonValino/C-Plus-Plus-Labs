#include <cstdlib>
#include <iostream>
#include <dirent.h>
#include <stdlib.h>
#include <string>
using namespace std;

class OpenDirectory
{
      private:
              std::string filePath;
              DIR *pdir;
              struct dirent *pent;
      public:
            string getDIRPath();
            bool openDIR(const char *pathIn);
            void closeDIR();
            OpenDirectory();
            OpenDirectory(const char *path);
};
