#include <cstdlib>
#include <iostream>
#include "OpenDirectory.h"
#include "ReadFile.h"
#include <string>

using namespace std;

int main(int argc, char *argv[])
{
    string path;
    string fileName;
    cout << "Enter the Path of the folder: ";
    cin >> path;
    const char *c = path.c_str(); //http://stackoverflow.com/questions/347949/how-to-convert-a-stdstring-to-const-char-or-char
    OpenDirectory o(c);
    cout << "Please select a file;\n";
    cout << "Enter file to open include its file type (EG myfile.txt):"<<endl; // user enters file to open & is not case senistive 
    cin >> fileName;
    ReadFile r(fileName,o.getDIRPath());
    r.openFile();
    cout << endl;
    system("PAUSE");
    return EXIT_SUCCESS;
}
