//
//  ListOfDoubles.cpp
//  LabWeek6
//
//  Created by Jake Valino on 06/12/2015.
//  Copyright © 2015 Jake Valino. All rights reserved.
//

#include "ListOfDoubles.hpp"
#include <iostream>
#include <cstdlib>
using namespace std;
//Default Constructor which sets the head to NULL
ListOfDoubles::ListOfDoubles()
:head(NULL)
{
    
}

//Clear Method
void ListOfDoubles::clear()
{
    DoubleListNode *tempPtr = head;
    while(tempPtr != NULL)
    {
        tempPtr = tempPtr->next;
        delete head;
        head = tempPtr;
    }
}

//Copy Constructor
ListOfDoubles::ListOfDoubles(const ListOfDoubles& l)
{
    if (this != &l) {
        DoubleListNode *origPtr = l.head,*copyPtr = NULL;
        while (origPtr != NULL) {
            if (head == NULL) {
                head = copyPtr = new DoubleListNode(origPtr->value);
            }else{
                copyPtr->next = new DoubleListNode(origPtr->value);
                copyPtr = copyPtr->next;
            }
            origPtr = origPtr->next;
        }
    }
}

//Overloaded assignment operator
const ListOfDoubles ListOfDoubles::operator=(const ListOfDoubles& l)
{
    if (this != &l) {
        if (head !=NULL) {
            clear();
        }
        DoubleListNode *origPtr = l.head,*copyPtr = NULL;
        while (origPtr != NULL) {
            if (head == NULL) {
                head = copyPtr = new DoubleListNode(origPtr->value);
            }else{
                copyPtr->next = new DoubleListNode(origPtr->value);
                copyPtr = copyPtr->next;
            }
            origPtr = origPtr->next;
        }
    }
    return *this;
}

//Overloaded stream operator<<
ostream& operator<<(ostream& outputStream,ListOfDoubles & l)
{
    DoubleListNode *tempPtr = l.head;
    while (tempPtr != NULL) {
        outputStream << tempPtr->getValue() << endl;
        tempPtr = tempPtr->getNext();
    }
    return outputStream;
}
//Deconstructor
ListOfDoubles::~ListOfDoubles()
{
    DoubleListNode *tempPtr = head;
    while(head)
    {
        tempPtr = tempPtr->next;
        delete head;
        head = tempPtr;
    }
}
//Insert a new node method at the end of the list
void ListOfDoubles::insert(double in)
{
    DoubleListNode *newNode = new DoubleListNode(in);
    newNode->next = head;
    head = newNode;
}

//Display this list of nodes method
void ListOfDoubles::displayList()
{
    DoubleListNode *tempPtr = head;
    while(tempPtr != NULL)
    {
        cout << tempPtr->value << endl;
        tempPtr = tempPtr->next;
    }
}

//Delete the most recent node added to the list
void ListOfDoubles::deleteMostRecent()
{
    DoubleListNode *tempPtr = head;
        tempPtr = tempPtr->next;
        delete head;
        head = tempPtr;
}

//Append a new node at the end of the list
void ListOfDoubles::append(double data)
{
    DoubleListNode *newNode = new DoubleListNode(data);
    
    DoubleListNode * tempPtr;
    
    if(!head)
    {
        head = newNode;
    }else
    {
        for (tempPtr = head; tempPtr->next; tempPtr =
             tempPtr-> next);
        tempPtr->next = newNode;
    }
}

//Delete the node added to the list at a particular position
void ListOfDoubles::deleteDouble(int pos)
{
    DoubleListNode *leadPtr = head,*trailPtr = NULL;
    if (head->value == pos) {
        leadPtr=leadPtr->next;
        delete head;
        head = leadPtr;
    }else{
        while (leadPtr != NULL && leadPtr->value != pos) {
            trailPtr = leadPtr;
            leadPtr = leadPtr->next;
        }
        if (leadPtr == NULL) {
            return;
        }else{
            trailPtr->next = leadPtr->next;
            delete leadPtr;
        }
    }
}
