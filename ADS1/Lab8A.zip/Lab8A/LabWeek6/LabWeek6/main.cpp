//
//  main.cpp
//  LabWeek6
//
//  Created by Jake Valino on 06/12/2015.
//  Copyright © 2015 Jake Valino. All rights reserved.
//

#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>
#include "ListOfDoubles.hpp"

using namespace std;

int main(int argc, char *argv[])
{
    ListOfDoubles l;
    cout << "Inserting" << endl;
    l.insert(1);
    cout << "Displaying:" << endl;
    l.displayList();
    cout << "Deleting Most Recent " << endl;
    l.deleteMostRecent();
    cout <<endl;
    cout << "Displaying:" << endl;
    l.displayList();
    cout << "Inserting" << endl;
    l.insert(1);
    cout << "Displaying:" << endl;
    l.displayList();
    cout << "Deleting a node at a specific location " << endl;
    l.deleteDouble(1);
    cout << "Displaying:" << endl;
    l.displayList();
    cout << "Appending:" << endl;
    l.insert(1);
    l.append(2);
    l.append(3);
    l.append(4);
    l.append(5);
    cout << "Displaying:" << endl;
    l.displayList();
    cout << "Deleting a node at a specific location " << endl;
    l.deleteDouble(3);
    cout << "Displaying:" << endl;
    l.displayList();
    cout << "Deleting Most Recent " << endl;
    l.deleteMostRecent();
    cout << "Deleting a node at a specific location " << endl;
    l.deleteDouble(2);
    cout << "Displaying:" << endl;
    l.displayList();
    
    cout << endl;
    cout << endl;
    cout << endl;
    cout << endl;
    
    ListOfDoubles la;
    la.append(1);
    la.append(2);
    la.append(3);
    la.displayList();
    
    cout << endl;
    cout << endl;
    cout << endl;
    cout << endl;
    
    ListOfDoubles le(la);
    le.displayList();
    
    cout << endl;
    cout << endl;
    cout << endl;
    cout << endl;
    
    ListOfDoubles li;
    li.append(1);
    li = le;
    cout << li;
    
    
    return 0;
    
    
}
