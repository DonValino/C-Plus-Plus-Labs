//
//  DoubleListNode.hpp
//  LabWeek6
//
//  Created by Jake Valino on 06/12/2015.
//  Copyright © 2015 Jake Valino. All rights reserved.
//

#ifndef DoubleListNode_hpp
#define DoubleListNode_hpp

#include <stdio.h>
#include <iostream>
#include <cstdlib>
using namespace std;

class DoubleListNode
{
    friend class ListOfDoubles;
    
private:
    double value;
    DoubleListNode *next;
public:
    DoubleListNode(double valueIn);
    double getValue();
    DoubleListNode *getNext();
};
#endif /* DoubleListNode_hpp */
