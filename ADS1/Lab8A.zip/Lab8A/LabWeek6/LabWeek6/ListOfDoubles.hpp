//
//  ListOfDoubles.hpp
//  LabWeek6
//
//  Created by Jake Valino on 06/12/2015.
//  Copyright © 2015 Jake Valino. All rights reserved.
//

#ifndef ListOfDoubles_hpp
#define ListOfDoubles_hpp

#include <stdio.h>
#include <iostream>
#include <cstdlib>
#include "DoubleListNode.hpp"
using namespace std;

class ListOfDoubles
{
private:
    DoubleListNode *head;
    friend ostream& operator<<(ostream& outputStream,ListOfDoubles & l);
public:
    ListOfDoubles();
    ListOfDoubles(const ListOfDoubles& l);
    ~ListOfDoubles();
    void append(double data);
    void insert(double);
    void displayList();
    void deleteMostRecent();
    void deleteDouble(int pos);
    void clear();
    
    const ListOfDoubles operator=(const ListOfDoubles& l);
    
};

#endif /* ListOfDoubles_hpp */
