//
//  DoubleListNode.cpp
//  LabWeek6
//
//  Created by Jake Valino on 06/12/2015.
//  Copyright © 2015 Jake Valino. All rights reserved.
//

#include "DoubleListNode.hpp"
#include <iostream>
#include <cstdlib>
using namespace std;

DoubleListNode::DoubleListNode(double valueIn)
{
    value = valueIn;
    next = NULL;
}


//Getter getValue
double DoubleListNode::getValue()
{
    return value;
}


//Getter getNext
DoubleListNode * DoubleListNode::getNext()
{
    return next;
}