//
//  EmployeeList.hpp
//  EmpLinkedList
//
//  Created by Jake Valino on 30/11/2015.
//  Copyright © 2015 Jake Valino. All rights reserved.
//

#ifndef EmployeeList_hpp
#define EmployeeList_hpp
#include "EmployeeNode.hpp"
#include <iostream>
#include <string>

using namespace std;
#include <stdio.h>
class EmployeeList
{
private:
    EmployeeNode *head;
    friend ostream& operator<<(ostream& outputStream,EmployeeList & l);
public:
    EmployeeList();
    EmployeeList(const EmployeeList& e);
    ~EmployeeList();
    void display();
    void addFront(int id,string name,double salary);
    void addEnd(int id,string name,double salary);
    void deleteNodeAtSpecificLocation(int id);
    void alterNodeAtSpecificLocation(int id);
    void deleteMostRecent();
    void clear();
    Employee findNodeAndReturnEmployeeObject(int id);
    
    const EmployeeList operator=(const EmployeeList& e);
};
#endif /* EmployeeList_hpp */
