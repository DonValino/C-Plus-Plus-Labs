//
//  EmployeeNode.hpp
//  EmpLinkedList
//
//  Created by Jake Valino on 30/11/2015.
//  Copyright © 2015 Jake Valino. All rights reserved.
//

#ifndef EmployeeNode_hpp
#define EmployeeNode_hpp
#include "Employee.hpp"
#include <iostream>
#include <string>

using namespace std;
#include <stdio.h>
class EmployeeNode
{
    friend class EmployeeList;
private:
    Employee e;
    EmployeeNode *next;
public:
    EmployeeNode(Employee eIn);
    void display();
    
    Employee getE();
    EmployeeNode *getNext();

};
#endif /* EmployeeNode_hpp */
