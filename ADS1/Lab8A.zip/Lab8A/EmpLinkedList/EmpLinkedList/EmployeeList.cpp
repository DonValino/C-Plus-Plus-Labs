//
//  EmployeeList.cpp
//  EmpLinkedList
//
//  Created by Jake Valino on 30/11/2015.
//  Copyright © 2015 Jake Valino. All rights reserved.
//

#include "EmployeeList.hpp"
#include <iostream>
#include <string>

using namespace std;

//Default Constructor
EmployeeList::EmployeeList()
:head(NULL)
{
    
}


//Copy Constructor
EmployeeList::EmployeeList(const EmployeeList& e)
{
    if(this != &e)
    {
        EmployeeNode *origPtr = e.head,*copyPtr = NULL;
        while (origPtr != NULL) {
            if(head == NULL)
            {
                Employee e(origPtr->e.id,origPtr->e.name,origPtr->e.salary);
                head = copyPtr = new EmployeeNode(e);
            }else
            {
                Employee e(origPtr->e.id,origPtr->e.name,origPtr->e.salary);
                copyPtr->next = new EmployeeNode(e);
            }
            origPtr = origPtr->next;
        }
    }
}

//Overloaded stream operator<<
ostream& operator<<(ostream& outputStream,EmployeeList & l)
{
    EmployeeNode *tempPtr = l.head;
    while (tempPtr != NULL) {
        outputStream << "ID: " << tempPtr->getE().getId() << "    Name: " << tempPtr->getE().getName() << "    Salary: " << tempPtr->getE().getSalary() << endl;
        tempPtr = tempPtr->getNext();
    }
    return outputStream;
}

//Overloaded Assignment Operator=
const EmployeeList EmployeeList::operator=(const EmployeeList& e)
{
    if(this != &e)
    {
        if(head != NULL)
        {
            clear();
        }
        EmployeeNode *origPtr = e.head,*copyPtr = NULL;
        while (origPtr != NULL) {
            if(head == NULL)
            {
                Employee e(origPtr->e.id,origPtr->e.name,origPtr->e.salary);
                head = copyPtr = new EmployeeNode(e);
            }else
            {
                Employee e(origPtr->e.id,origPtr->e.name,origPtr->e.salary);
                copyPtr->next = new EmployeeNode(e);
            }
            origPtr = origPtr->next;
        }
    }
    return *this;
}


//Destructor
EmployeeList::~EmployeeList()
{
    EmployeeNode *tempPtr = head;
    while (head) {
        tempPtr = tempPtr->next;
        delete head;
        head = tempPtr;
    }
}


//Display Method
void EmployeeList::display()
{
    EmployeeNode *tempPtr = head;
    while (tempPtr != NULL) {
        cout << "ID: " << tempPtr->e.id << "    Name: " << tempPtr->e.name << "    Salary: " << tempPtr->e.salary << endl;
        tempPtr = tempPtr->next;
    }
}


//Add a node to the front of the list
void EmployeeList::addFront(int id,string name,double salary)
{
    Employee e(id,name,salary);
    EmployeeNode *newNode = new EmployeeNode(e);
    newNode->next = head;
    head = newNode;
}

//Add a node to the end of the list
void EmployeeList::addEnd(int id,string name,double salary)
{
    Employee e(id,name,salary);
    EmployeeNode *newNode = new EmployeeNode(e);
    EmployeeNode *tempPtr = NULL;
    if(!head)
    {
        head = newNode;
    }else
    {
        for(tempPtr = head;tempPtr->next;tempPtr=tempPtr->next);
        tempPtr->next = newNode;
    }
}

//Delete Node at specific Location in hte list
void EmployeeList::deleteNodeAtSpecificLocation(int id)
{
    EmployeeNode *leadPtr = head,*trailPtr=NULL;
    if(head->e.id == id)
    {
        leadPtr = leadPtr->next;
        delete head;
        head = leadPtr;
    }else{
        while (leadPtr != NULL && leadPtr->e.id != id) {
            trailPtr = leadPtr;
            leadPtr = leadPtr->next;
        }
        if (leadPtr == NULL) {
            return;
        }else
        {
            trailPtr->next = leadPtr->next;
            delete leadPtr;
        }
    }
}

//Alter Node at specific Location in hte list
void EmployeeList::alterNodeAtSpecificLocation(int id)
{
    EmployeeNode *leadPtr = head,*trailPtr=NULL;
    if(head->e.id == id)
    {
        cout << "Enter ID:\n";
        cin >> head->e.id;
        cout << "Enter Name:\n";
        cin >> head->e.name;
        cout << "Enter Salary:\n";
        cin >> head->e.salary;
    }else{
        while (leadPtr != NULL && leadPtr->e.id != id) {
            trailPtr = leadPtr;
            leadPtr = leadPtr->next;
        }
        if (leadPtr == NULL) {
            return;
        }else
        {
            cout << "Enter ID:\n";
            cin >> leadPtr->e.id;
            cout << "Enter Name:\n";
            cin >> leadPtr->e.name;
            cout << "Enter Salary:\n";
            cin >> leadPtr->e.salary;
        }
    }
}


//Delete the most recently added Node in the list
void EmployeeList::deleteMostRecent()
{
    EmployeeNode *tempPtr = head;
        tempPtr = tempPtr->next;
        delete head;
        head = tempPtr;
}


//Clear Method
void EmployeeList::clear()
{
    EmployeeNode *tempPtr = head;
    while (tempPtr != NULL) {
        tempPtr = tempPtr->next;
        delete head;
        head = tempPtr;
    }
}


//Find a Node And Return its Employee Object
Employee EmployeeList::findNodeAndReturnEmployeeObject(int id)
{
    EmployeeNode *leadPtr = head,*trailPtr=NULL;
    Employee *e = new Employee();
    if(head->e.id == id)
    {
        e = new Employee(head->e.id,head->e.name,head->e.salary);
    }else{
        while (leadPtr != NULL && leadPtr->e.id != id) {
            trailPtr = leadPtr;
            leadPtr = leadPtr->next;
        }
        if (leadPtr == NULL) {
           cout << "Node Not Found";
        }else
        {
            e = new Employee(head->e.id,head->e.name,head->e.salary);
        }
    }
    return *e;
}







