//
//  Employee.cpp
//  EmpLinkedList
//
//  Created by Jake Valino on 30/11/2015.
//  Copyright © 2015 Jake Valino. All rights reserved.
//

#include "Employee.hpp"
#include <iostream>
#include <string>

using namespace std;

//Default Constructor
Employee::Employee()
{
    id = 0;
    name = "";
    salary = 0;
}

//Constructor
Employee::Employee(int idIn,string nameIn,double salaryIn)
{
    id = idIn;
    name = nameIn;
    salary = salaryIn;
}


//Destructor
Employee::~Employee()
{
    id = 0;
    name = "";
    salary = 0;
}


//Display Method
void Employee::display()
{
    cout << "ID: " << id << "    Name: " << name << "    Salary: " << salary << endl;
}


//Overloaded plus operator+
const Employee Employee::operator+(const Employee& emp)
{
    salary = salary + emp.salary;
    return *this;
}

//Overloaded minus operator-
const Employee Employee::operator-(const Employee& emp)
{
    salary = salary - emp.salary;
    return *this;
}

//Overloaded multiply operator*
const Employee Employee::operator*(int num)
{
    salary = salary * num;
    return *this;
}

//Overloaded divide operator/
const Employee Employee::operator/(const Employee& emp)
{
    salary = salary / emp.salary;
    return *this;
}

//Overloaded cin operator>> friend method
istream& operator>>(istream& inputStream,Employee& emp)
{
    cout << "Enter ID:\n";
    inputStream >> emp.id;
    cout << "Enter Name:\n";
    inputStream >> emp.name;
    cout << "Enter Salary:\n";
    inputStream >> emp.salary;
    return inputStream;
}

//Overloaded cout operator<< friend method
ostream& operator<<(ostream& outpuStream,Employee& emp)
{
    outpuStream << "ID: " << emp.id << "    Name: " << emp.name << "    Salary: " << emp.salary << endl;
    return outpuStream;
}

//Getters
int Employee::getId()
{
    return id;
}
string Employee::getName()
{
    return name;
}
double Employee::getSalary()
{
    return salary;
}



