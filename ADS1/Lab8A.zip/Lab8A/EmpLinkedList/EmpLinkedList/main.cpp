//
//  main.cpp
//  EmpLinkedList
//
//  Created by Jake Valino on 30/11/2015.
//  Copyright © 2015 Jake Valino. All rights reserved.
//

#include <iostream>
#include <string>
#include "EmployeeList.hpp"
using namespace std;

int main(int argc, const char * argv[]) {
    // insert code here...
    EmployeeList e;
    e.addEnd(2, "Mary", 10000);
    e.addFront(1, "Jake", 20000);
    e.deleteNodeAtSpecificLocation(2);
    e.addEnd(2, "Mary", 10000);
    e.alterNodeAtSpecificLocation(2);
    e.deleteMostRecent();
    e.addFront(1, "Jake", 20000);
    e.display();
    
    cout << endl;
    cout << endl;
    cout << endl;
    cout << endl;
    
    EmployeeList e1(e);
    e1.display();
    
    cout << endl;
    cout << endl;
    cout << endl;
    cout << endl;
    
    EmployeeList e2;
    e2.addFront(1, "LALA", 50000);
    e2.addEnd(2, "Josh Peck", 90000);
    e2 = e1;
    e2.display();

    cout << endl;
    cout << endl;
    cout << endl;
    cout << endl;
    
    Employee emp = e2.findNodeAndReturnEmployeeObject(1);
    Employee emp1 = e2.findNodeAndReturnEmployeeObject(2);
    emp = emp + emp1;
    emp = emp - emp1;
    emp = emp * 2;
    emp = emp / emp1;
    cin >> emp;
    cout << emp;
    
    cout << endl;
    cout << endl;
    cout << endl;
    cout << endl;
    
    EmployeeList empList;
    empList.addEnd(1, "Jake", 10);
    cout << empList;
    return 0;
}




