//
//  Employee.hpp
//  EmpLinkedList
//
//  Created by Jake Valino on 30/11/2015.
//  Copyright © 2015 Jake Valino. All rights reserved.
//

#ifndef Employee_hpp
#define Employee_hpp
#include <iostream>
#include <string>

using namespace std;
#include <stdio.h>
class Employee
{
    friend class EmployeeNode;
    friend class EmployeeList;
    friend istream& operator>>(istream& inputStream,Employee& emp);
    friend ostream& operator<<(ostream& outpuStream,Employee& emp);
private:
    int id;
    string name;
    double salary;
public:
    Employee(int idIn,string nameIn,double salaryIn);
    ~Employee();
    Employee();
    void display();
    int getId();
    string getName();
    double getSalary();
    
    const Employee operator+(const Employee& emp);
    const Employee operator-(const Employee& emp);
    const Employee operator*(int num);
    const Employee operator/(const Employee& emp);
};

#endif /* Employee_hpp */
