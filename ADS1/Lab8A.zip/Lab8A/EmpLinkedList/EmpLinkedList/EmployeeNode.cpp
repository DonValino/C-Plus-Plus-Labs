//
//  EmployeeNode.cpp
//  EmpLinkedList
//
//  Created by Jake Valino on 30/11/2015.
//  Copyright © 2015 Jake Valino. All rights reserved.
//

#include "EmployeeNode.hpp"
#include <iostream>
#include <string>

using namespace std;

//Constructor
EmployeeNode::EmployeeNode(Employee eIn)
{
    e = eIn;
    next = NULL;
}


//Display Method
void EmployeeNode::display()
{
     cout << "ID: " << e.id << "    Name: " << e.name << "    Salary: " << e.salary << endl;
}


//Getter
Employee EmployeeNode::getE()
{
    return e;
}

EmployeeNode *EmployeeNode::getNext()
{
    return next;
}