//
//  StackOfDoubles.hpp
//  StackLinkList
//
//  Created by Jake Valino on 18/11/2015.
//  Copyright © 2015 Jake Valino. All rights reserved.
//

#ifndef StackOfDoubles_hpp
#define StackOfDoubles_hpp
#include "ListOfDoubles.hpp"
#include <stdio.h>
#include <iostream>
#include <string>
using namespace std;

class StackOfDoubles
{
    friend ostream& operator<<(ostream& outputStream,StackOfDoubles& stack);
private:
    ListOfDoubles list;
public:
    StackOfDoubles();
    StackOfDoubles(const StackOfDoubles& s);
    void push(double in);
    void pop();
    void display();
    DoubleListNode top();
    
    const StackOfDoubles operator=(const StackOfDoubles& s);
};
#endif /* StackOfDoubles_hpp */
