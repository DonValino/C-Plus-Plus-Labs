//
//  QueueOfDoubles.cpp
//  StackLinkList
//
//  Created by Jake Valino on 18/11/2015.
//  Copyright © 2015 Jake Valino. All rights reserved.
//

#include "QueueOfDoubles.hpp"
#include <iostream>
#include <string>
using namespace std;

//Constructor
QueueOfDoubles::QueueOfDoubles()
{
    list.append(1);
    list.append(2);
    list.append(3);
    list.append(4);
    list.append(5);
}

//Push method to insert data at the end of the stack
void QueueOfDoubles::push(double in)
{
    list.append(in);
}

//Pop Method to remove the data at that's the latest that was first was inserted to the stack (FIFO)
void QueueOfDoubles::pop()
{
    list.removeHead();
}

//returns the top item from the stack without removing it
DoubleListNode QueueOfDoubles::top()
{
    return list.findMostRecent();
}

//Display the doubles in the stack
void QueueOfDoubles::display()
{
    list.displayList();
}

//overloaded insertion operator to insert the contents of the stack (tab separated) into an output stream
ostream& operator<<(ostream& outputStream,QueueOfDoubles& stack)
{
    vector<double> d = stack.list.returnList();
    for (int i=0; i < (d.size());i++){
        outputStream << d[i] << endl;
    }
    return outputStream;
}