//
//  QueueOfDoubles.hpp
//  StackLinkList
//
//  Created by Jake Valino on 18/11/2015.
//  Copyright © 2015 Jake Valino. All rights reserved.
//

#ifndef QueueOfDoubles_hpp
#define QueueOfDoubles_hpp
#include "ListOfDoubles.hpp"
#include <stdio.h>
#include <iostream>
#include <string>
using namespace std;

class QueueOfDoubles
{
    friend ostream& operator<<(ostream& outputStream,QueueOfDoubles& stack);
private:
    ListOfDoubles list;
public:
    QueueOfDoubles();
    void push(double in);
    void pop();
    void display();
    DoubleListNode top();
};
#endif /* QueueOfDoubles_hpp */
