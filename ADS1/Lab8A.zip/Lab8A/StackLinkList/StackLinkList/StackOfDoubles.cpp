//
//  StackOfDoubles.cpp
//  StackLinkList
//
//  Created by Jake Valino on 18/11/2015.
//  Copyright © 2015 Jake Valino. All rights reserved.
//

#include "StackOfDoubles.hpp"
#include <iostream>
#include <string>
#include <vector>
using namespace std;

//Default Constructor
StackOfDoubles::StackOfDoubles()
{
    list.append(1);
    list.append(2);
    list.append(3);
    list.append(4);
    list.append(5);

}

//Push method to push values in the end of the stack
void StackOfDoubles::push(double in)
{
    list.append(in);
}

//Pop method to remove the value in the end of the stack
void StackOfDoubles::pop()
{
    list.deleteMostRecent();
}
//returns the top item from the stack without removing it
DoubleListNode StackOfDoubles::top()
{
    return list.findMostRecent();
}


//Display the doubles in the stack
void StackOfDoubles::display()
{
    list.displayList();
}

//overloaded insertion operator to insert the contents of the stack (tab separated) into an output stream
ostream& operator<<(ostream& outputStream,StackOfDoubles& stack)
{
    vector<double> d = stack.list.returnList();
    for (int i=0; i < (d.size());i++){
    outputStream << d[i] << endl;
    }
    return outputStream;
}


//Overloaded assignment operator
StackOfDoubles::StackOfDoubles(const StackOfDoubles& s)
{
    if (this != &s) {
        DoubleListNode *oridPtr = s.list.head,*copyPtr = NULL;
        while (oridPtr != NULL) {
            if (list.head == NULL) {
                list.head = copyPtr = new DoubleListNode(oridPtr->value);
            }else{
                copyPtr->next = new DoubleListNode(oridPtr->value);
                copyPtr = copyPtr->next;
            }
            oridPtr= oridPtr->next;
        }
    }
}

//Overloaded assignment operator=
const StackOfDoubles StackOfDoubles::operator=(const StackOfDoubles& s)
{
    if (this != &s) {
        if (list.head != NULL) {
            list.clear();
        }
        DoubleListNode *oridPtr = s.list.head,*copyPtr = NULL;
        while (oridPtr != NULL) {
            if (list.head == NULL) {
                list.head = copyPtr = new DoubleListNode(oridPtr->value);
            }else{
                copyPtr->next = new DoubleListNode(oridPtr->value);
                copyPtr = copyPtr->next;
            }
            oridPtr= oridPtr->next;
        }
    }
    return *this;
}




