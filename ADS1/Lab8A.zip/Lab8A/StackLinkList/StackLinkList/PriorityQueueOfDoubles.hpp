//
//  PriorityQueueOfDoubles.hpp
//  StackLinkList
//
//  Created by Jake Valino on 18/11/2015.
//  Copyright © 2015 Jake Valino. All rights reserved.
//

#ifndef PriorityQueueOfDoubles_hpp
#define PriorityQueueOfDoubles_hpp
#include <iostream>
#include <string>
#include <vector>
using namespace std;
#include <stdio.h>
class PriorityQueueOfDoubles
{
    friend ostream& operator<<(ostream& outputStream,PriorityQueueOfDoubles& stack);
private:
    vector<double> list;
public:
    PriorityQueueOfDoubles();
    void push(double in);
    void pop();
    void display();
    double top();
};
#endif /* PriorityQueueOfDoubles_hpp */
