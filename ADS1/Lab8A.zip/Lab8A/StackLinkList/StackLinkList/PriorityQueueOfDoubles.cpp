//
//  PriorityQueueOfDoubles.cpp
//  StackLinkList
//
//  Created by Jake Valino on 18/11/2015.
//  Copyright © 2015 Jake Valino. All rights reserved.
//

#include "PriorityQueueOfDoubles.hpp"
#include <iostream>
#include <string>
#include <vector>
using namespace std;

//Default Constructor
PriorityQueueOfDoubles::PriorityQueueOfDoubles()
{
    list.push_back(1);
    list.push_back(2);
    list.push_back(3);
    list.push_back(4);
    list.push_back(5);
}

//Push method to insert data at the end of the stack
void PriorityQueueOfDoubles::push(double in)
{
    list.push_back(in);
}

//Pop Method to remove the most recently added data from the stack
void PriorityQueueOfDoubles::pop()
{
    list.pop_back();
}

//Display Method to display the data in the stack
void PriorityQueueOfDoubles::display()
{
    for(int i =0; i < list.size();i++)
    {
        cout << list[i];
    }
}

//Top Method to display the top of the stack
double PriorityQueueOfDoubles::top()
{
    return list[0];
}

//overloaded insertion operator to insert the contents of the stack (tab separated) into an output stream
ostream& operator<<(ostream& outputStream,PriorityQueueOfDoubles& stack)
{
    for (int i=0; i < stack.list.size();i++){
        outputStream << stack.list[i] << endl;
    }
    return outputStream;
}