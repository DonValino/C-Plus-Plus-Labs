//
//  main.cpp
//  StackLinkList
//
//  Created by Jake Valino on 18/11/2015.
//  Copyright © 2015 Jake Valino. All rights reserved.
//

#include "ListOfDoubles.hpp"
#include <iostream>
#include <iostream>
#include <string>
#include "StackOfDoubles.hpp"
#include "QueueOfDoubles.hpp"
#include "PriorityQueueOfDoubles.hpp"
using namespace std;
int main(int argc, const char * argv[]) {
    // (1) Stack LinkedList
    /*StackOfDoubles s;
    s.pop();
    s.display();
    cout << endl;
    cout << endl;
    DoubleListNode d = s.top();
    d.display();
    cout << endl;
    cout << endl;
    cout << s;
    cout << endl;
    cout << endl;
    StackOfDoubles s1(s);
    cout << s1;
    cout << endl;
    cout << endl;
    StackOfDoubles s2;
    s2.push(1);
    s2 = s1;
    cout << s2;8?
    
    //(2) Queue Of Doubles
    /*QueueOfDoubles q;
    q.push(6);
    q.pop();
    q.display();
    cout << endl;
    cout << endl;
    
    DoubleListNode d = q.top();
    d.display();
    cout << endl;
    cout << endl;
    
    cout << q;*/
    
    //(3) Priority Queue Of Doubles
    /*PriorityQueueOfDoubles p;
    p.push(6);
    p.pop();
    cout << p;
    cout << endl;
    double top = p.top();
    cout << top << endl;
    return 0;*/
}
