//
//  ListOfDoubles.cpp
//  StackLinkList
//
//  Created by Jake Valino on 18/11/2015.
//  Copyright © 2015 Jake Valino. All rights reserved.
//

#include "ListOfDoubles.hpp"
#include <iostream>
#include <cstdlib>
#include <vector>
using namespace std;
//Default Constructor which sets the head to NULL
ListOfDoubles::ListOfDoubles()
:head(NULL)
{
    
}
//Deconstructor
ListOfDoubles::~ListOfDoubles()
{
    DoubleListNode *tempPtr;
    while(head)
    {
        tempPtr = head;
        head = head->next;
        delete tempPtr;
    }
}
//Insert a new node method at the end of the list
void ListOfDoubles::insert(double in)
{
    DoubleListNode *newNode = new DoubleListNode(in);
    newNode->next = head;
    head = newNode;
}

//Display this list of nodes method
void ListOfDoubles::displayList()
{
    DoubleListNode *tempPtr = head;
    while(tempPtr != NULL)
    {
        cout << tempPtr->value << endl;
        tempPtr = tempPtr->next;
    }
}

//Remove the data in the head of the list
void ListOfDoubles::removeHead()
{
    DoubleListNode *tempPtr = head;
    tempPtr = tempPtr->next;
    delete head;
    head = tempPtr;
}

//Delete the most recent node added to the list
void ListOfDoubles::deleteMostRecent()
{
    DoubleListNode *tempPtr = head;
    tempPtr = tempPtr->next;
    delete head;
    head = tempPtr;
    
}

//Append a new node at the end of the list
void ListOfDoubles::append(double data)
{
    DoubleListNode *newNode = new DoubleListNode(data);
    
    DoubleListNode * tempPtr;
    
    if(!head)
    {
        head = newNode;
    }else
    {
        for (tempPtr = head; tempPtr->next; tempPtr =
             tempPtr-> next);
        tempPtr->next = newNode;
    }
}

//Find the most recently added node in the list
DoubleListNode ListOfDoubles::findMostRecent()
{
    DoubleListNode * tempPtr;
    
        for (tempPtr = head; tempPtr->next; tempPtr =
             tempPtr-> next);
    return *tempPtr;
}

//Delete the node added to the list at a particular position
int ListOfDoubles::deleteDouble(int pos)
{
    DoubleListNode *tempPtr = head;
    if(head && head->next)
    {
        if(pos == 1)
        {
            head = head->next;
        }else
        {
            pos--;
            while(pos)
            {
                tempPtr = tempPtr->next;
                pos--;
            }
        }
    }else if(head && !head->next)
    {
        if(pos == 1)
        {
            head = NULL;
        }else
        {
            cout << "Error, specified location does not exist";
        }
    }
    delete tempPtr;
    return 0;
}

//Display this list of nodes method
vector<double> ListOfDoubles::returnList()
{
    DoubleListNode *tempPtr = head;
    vector<double> d;
    while(tempPtr != NULL)
    {
        d.push_back(tempPtr->value);
        tempPtr = tempPtr->next;
    }
    return d;
}

//void clear();
void ListOfDoubles::clear(){
    DoubleListNode *tempPtr = head;
    while(tempPtr != NULL)
    {
        tempPtr = tempPtr->next;
        delete head;
        head = tempPtr;
    }
}


