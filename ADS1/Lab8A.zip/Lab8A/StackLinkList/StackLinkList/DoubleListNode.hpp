//
//  DoubleListNode.hpp
//  StackLinkList
//
//  Created by Jake Valino on 18/11/2015.
//  Copyright © 2015 Jake Valino. All rights reserved.
//

#ifndef DoubleListNode_hpp
#define DoubleListNode_hpp

#include <stdio.h>
#include <iostream>
#include <cstdlib>
using namespace std;

class DoubleListNode
{
    friend class ListOfDoubles;
    friend class StackOfDoubles;
    
private:
    double value;
    DoubleListNode *next;
public:
    DoubleListNode(double valueIn);
    void display();
};
#endif /* DoubleListNode_hpp */
