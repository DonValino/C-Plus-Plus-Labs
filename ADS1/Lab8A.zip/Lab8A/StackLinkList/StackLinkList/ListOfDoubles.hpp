//
//  ListOfDoubles.hpp
//  StackLinkList
//
//  Created by Jake Valino on 18/11/2015.
//  Copyright © 2015 Jake Valino. All rights reserved.
//

#ifndef ListOfDoubles_hpp
#define ListOfDoubles_hpp

#include <stdio.h>
#include <iostream>
#include <vector>
#include <cstdlib>
#include "DoubleListNode.hpp"
using namespace std;

class ListOfDoubles
{
private:
    DoubleListNode *head;
    friend class StackOfDoubles;
public:
    ListOfDoubles();
    ~ListOfDoubles();
    void append(double data);
    void insert(double);
    void removeHead();
    void displayList();
    void deleteMostRecent();
    int deleteDouble(int pos);
    DoubleListNode findMostRecent();
    vector<double> returnList();
    void clear();
    
};
#endif /* ListOfDoubles_hpp */
