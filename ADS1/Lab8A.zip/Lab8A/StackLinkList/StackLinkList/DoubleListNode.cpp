//
//  DoubleListNode.cpp
//  StackLinkList
//
//  Created by Jake Valino on 18/11/2015.
//  Copyright © 2015 Jake Valino. All rights reserved.
//

#include "DoubleListNode.hpp"
#include <iostream>
#include <cstdlib>
using namespace std;

//Constructor
DoubleListNode::DoubleListNode(double valueIn)
{
    value = valueIn;
    next = NULL;
}

//Display the values in the node
void DoubleListNode::display()
{
    cout << "Double IS: " << value << endl;
}