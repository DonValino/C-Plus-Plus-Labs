#include <cstdlib>
#include <iostream>
#include "EmployeeList.h"
using namespace std;

int main(int argc, char *argv[])
{
    EmployeeList e;
    e.addEnd(2,"Mary",10000);
    e.addFront(1,"Jake",100000);
    e.deleteMostRecent();
    e.addFront(1,"Jake",100000);
    e.deleteNodeAtASpecificLocation(2);
    e.alterNodeAtASpecificLocation("Jake");
    e.display();
    
    cout << endl;
    cout << endl;
    cout << endl;
    cout << endl;
    
    EmployeeList e2(e);
    e2.display();
    
    cout << endl;
    cout << endl;
    cout << endl;
    cout << endl;
    
    EmployeeList e3;
    e3 = e2;
    e3.display();
    
    cout << endl;
    cout << endl;
    cout << endl;
    cout << endl;
    
    Employee eN(1,"Jake Valino",800000);
    EmployeeNode empN(eN);
    Employee eN1(2,"Shane",800000);
    EmployeeNode empN1(eN);
   
    empN.display();
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
