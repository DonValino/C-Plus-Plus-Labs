#include <iostream>
#include <string>
#include "EmployeeNode.h"

using namespace std;


class EmployeeList
{
      private:
              EmployeeNode *head;
      public:
             EmployeeList();
             ~EmployeeList();
             EmployeeList(const EmployeeList& emp);
             void display();
             void addFront(int id,string name,double salary);
             void addEnd(int id,string name,double salary);
             void deleteMostRecent();
             void clear();
             void deleteNodeAtASpecificLocation(int id);
             void alterNodeAtASpecificLocation(string name);
             
             const EmployeeList operator=(const EmployeeList& emp);
};
