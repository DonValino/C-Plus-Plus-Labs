#include <iostream>
#include <string>
using namespace std;

class Employee
{
      friend class EmployeeNode;
      friend class EmployeeList;
      private:
              int id;
              string name;
              double salary;
      public:
             Employee(int idIn,string nameIn,double salaryIn);
             Employee();
             ~Employee();
             
};
