#include <iostream>
#include <string>
#include "EmployeeNode.h"

using namespace std;

//Constructor
EmployeeNode::EmployeeNode(Employee eIn)
{
   e = eIn;
   next = NULL;
}

//Destructor
EmployeeNode::~EmployeeNode()
{
   e.id = 0;
   e.name = "";
   e.salary = 0;
}

//Display Method
void EmployeeNode::display()
{
     cout << "ID is: " << e.id << "\nName is: " << e.name << "\nSalary is: " << e.salary << endl;
}


//Overloaded plus operator+
const EmployeeNode EmployeeNode::operator+(const EmployeeNode& emp)
{
      e.salary = e.salary + emp.e.salary;
      return *this;
}
