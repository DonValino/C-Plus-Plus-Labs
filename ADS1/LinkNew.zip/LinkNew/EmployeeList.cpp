#include <iostream>
#include <string>
#include "EmployeeList.h"

using namespace std;

//Default Constructor
EmployeeList::EmployeeList()
:head(NULL)
{
}

//Destructor
EmployeeList::~EmployeeList()
{
   EmployeeNode *tempPtr = head;
   while(head)
   {
     tempPtr = tempPtr->next;
     delete head;
     head = tempPtr;
   }
}

//Copy Constructor
EmployeeList::EmployeeList(const EmployeeList& emp)
:head(NULL)
{
   if(this != &emp)
   {
     EmployeeNode *origPtr = emp.head,*copyPtr = NULL;
     while(origPtr != NULL)
     {
       if(head == NULL)
       {
               Employee e(origPtr->e.id,origPtr->e.name,origPtr->e.salary);
               head = copyPtr = new EmployeeNode(e);
       }else
       {
            Employee e(origPtr->e.id,origPtr->e.name,origPtr->e.salary);
            copyPtr->next = new EmployeeNode(e);
            copyPtr = copyPtr->next;
       }
       origPtr = origPtr->next;
     }
   }
}

//Overloaded Assignment operator=
const EmployeeList EmployeeList::operator=(const EmployeeList& emp)
{
  if(this != &emp)
   {
     if(head != NULL)
     {
        clear();
     }
     EmployeeNode *origPtr = emp.head,*copyPtr = NULL;
     while(origPtr != NULL)
     {
       if(head == NULL)
       {
               Employee e(origPtr->e.id,origPtr->e.name,origPtr->e.salary);
               head = copyPtr = new EmployeeNode(e);
       }else
       {
            Employee e(origPtr->e.id,origPtr->e.name,origPtr->e.salary);
            copyPtr->next = new EmployeeNode(e);
            copyPtr = copyPtr->next;
       }
       origPtr = origPtr->next;
     }
   } 
   return *this;   
}


//Display A node
void EmployeeList::display()
{
   EmployeeNode *tempPtr = head;
   while(tempPtr != NULL)
   {
      cout << "ID is: " << tempPtr->e.id << "\nName is: " << tempPtr->e.name << "\nSalary is: " << tempPtr->e.salary << endl;
      tempPtr = tempPtr->next;
   }
}


//Add a node to the front of the list
void EmployeeList::addFront(int id,string name,double salary)
{
     Employee e1(id,name,salary);
     EmployeeNode *newNode = new EmployeeNode(e1);   
     
     newNode->next = head;
     head = newNode; 
}


//Add a node to the end of the list
void EmployeeList::addEnd(int id,string name,double salary)
{
   Employee e(id,name,salary);
   EmployeeNode *newNode = new EmployeeNode(e);
   EmployeeNode *tempPtr = NULL;
   
   if(!head)
   {
     head = newNode;
   }else
   {
        for(tempPtr = head;tempPtr->next;tempPtr=tempPtr->next);
        tempPtr->next = head;
   }
}


//Delete the most recently added node in the list
void EmployeeList::deleteMostRecent()
{
   EmployeeNode *tempPtr = head;
     tempPtr = tempPtr->next;
     delete head;
     head = tempPtr;
}

//Clear Method
void EmployeeList::clear()
{
   EmployeeNode *tempPtr = head;
   while(tempPtr != NULL)
   {
     tempPtr = tempPtr->next;
     delete head;
     head = tempPtr;
   } 
}

//Delete Node at a specific location in the list
void EmployeeList::deleteNodeAtASpecificLocation(int id)
{
     EmployeeNode *leadPtr = head,*trailPtr = NULL;
     
     if(head->e.id == id)
     {
        leadPtr = leadPtr->next;
        delete head;
        head = leadPtr;
     }else
     {
          while(leadPtr != NULL && leadPtr->e.id != id)
          {
             trailPtr = leadPtr;
             leadPtr = leadPtr->next;
          }
          if(leadPtr == NULL)
          {
            return;
          }else
          {
               trailPtr->next = leadPtr->next;
               delete leadPtr;
          }
     }
}

//Alter Node at a specific location in the list
void EmployeeList::alterNodeAtASpecificLocation(string name)
{
   EmployeeNode *leadPtr = head,*trailPtr = NULL;
   int idIn = 0;
   string nameIn = "";
   double salaryIn = 0;
     
     if(head->e.name == name)
     {
       cout << "Enter ID: ";
       cin >> idIn;
       cout << endl;
       cout << "Enter Name: ";
       cin >> nameIn;
       cout << endl;
       cout << "Enter salary: ";
       cin >> salaryIn;
       cout << endl;
       head->e.id = idIn;
       head->e.name = nameIn;
       head->e.salary = salaryIn;
     }else
     {
          while(leadPtr != NULL && leadPtr->e.name != name)
          {
             trailPtr = leadPtr;
             leadPtr = leadPtr->next;
          }
          if(leadPtr == NULL)
          {
            return;
          }else
          {
            cout << "Enter ID: ";
            cin >> idIn;
            cout << endl;
            cout << "Enter Name: ";
            cin >> nameIn;
            cout << endl;
            cout << "Enter salary: ";
            cin >> salaryIn;
            cout << endl;
            leadPtr->e.id = idIn;
            leadPtr->e.name = nameIn;
            leadPtr->e.salary = salaryIn;
          }
     }    
}
