#include <iostream>
#include <string>
#include "Employee.h"
using namespace std;

class EmployeeNode
{
      friend class EmployeeList;
      private:
              Employee e;
              EmployeeNode *next;
      public:
             EmployeeNode(Employee eIn);
             EmployeeNode(const EmployeeNode& emp);
             ~EmployeeNode();
             void display();
             
            const EmployeeNode operator+(const EmployeeNode& emp);

};
