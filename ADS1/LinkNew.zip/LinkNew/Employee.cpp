#include <iostream>
#include <string>
#include "Employee.h"

using namespace std;

//Default Constructor
Employee::Employee()
{
  id = 0;
  name = "";
  salary = 0;
}

//Constructor
Employee::Employee(int idIn,string nameIn,double salaryIn)
{
  id = idIn;
  name = nameIn;
  salary = salaryIn;
}

//Destructor
Employee::~Employee()
{
  id = 0;
  name = "";
  salary = 0;
}


